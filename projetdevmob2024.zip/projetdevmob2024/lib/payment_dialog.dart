import 'package:flutter/material.dart';

class PaymentDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Paiement",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text("Veuillez sélectionner un mode de paiement pour confirmer votre réservation."),
            SizedBox(height: 20),
            // Option 1: Paiement par carte bancaire
            ElevatedButton(
              onPressed: () {
                // Logique pour procéder au paiement par carte bancaire
                _proceedToPayment(context, "Carte bancaire");
              },
              child: Text("Payer par carte bancaire"),
            ),
            SizedBox(height: 10),
            // Option 2: Paiement via PayPal
            ElevatedButton(
              onPressed: () {
                // Logique pour procéder au paiement via PayPal
                _proceedToPayment(context, "PayPal");
              },
              child: Text("Payer via PayPal"),
            ),
            SizedBox(height: 10),
            // Option 3: Autre mode de paiement (exemple)
            ElevatedButton(
              onPressed: () {
                // Logique pour un autre mode de paiement (exemple: paiement par cryptomonnaie)
                _proceedToPayment(context, "Cryptomonnaie");
              },
              child: Text("Payer par Cryptomonnaie"),
            ),
          ],
        ),
      ),
    );
  }

  // Méthode pour traiter le paiement et fermer le dialogue
  void _proceedToPayment(BuildContext context, String paymentMethod) {
    // Vous pouvez ajouter ici la logique spécifique au mode de paiement choisi

    // Exemple: Afficher un message de confirmation
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Paiement confirmé"),
        content: Text("Le paiement par $paymentMethod a été effectué avec succès."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Fermer le dialogue de paiement
              Navigator.pop(context); // Fermer le dialogue principal
            },
            child: Text("OK"),
          ),
        ],
      ),
    );
  }
}
