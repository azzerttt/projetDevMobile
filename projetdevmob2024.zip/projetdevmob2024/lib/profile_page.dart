// profile_page.dart
import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mon Profil"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage('https://example.com/user_profile_image.jpg'), // Image de profil (remplacer avec une URL valide)
            ),
            SizedBox(height: 20),
            Text(
              "Nom : alpha Toure", // Remplacer avec des données réelles
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text("Email : talpha529@gmail.com", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Text(
              "Réservations passées",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            // Exemple de liste de réservations
            ListView.builder(
              shrinkWrap: true,
              itemCount: 3, // Nombre de réservations passées (à ajuster dynamiquement)
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  child: ListTile(
                    title: Text("Réservation #${index + 1}", style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("Véhicule : Voiture ${index + 1}"),
                    trailing: Icon(Icons.arrow_forward),
                    onTap: () {
                      // Action pour afficher les détails de la réservation
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
