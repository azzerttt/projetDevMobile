import 'package:flutter/material.dart';
import 'evaluation_manager.dart';
import 'voiture.dart';
import 'reservation_form_page.dart';

class ReservationPage extends StatefulWidget {
  @override
  _ReservationPageState createState() => _ReservationPageState();
}

class _ReservationPageState extends State<ReservationPage> {
  final List<Voiture> voitures = List.generate(
    10,
    (index) => Voiture(
      nom: "Voiture ${index + 1}",
      prix: 50.0 + (index * 5),
      estDisponible: index % 2 == 0, // Alternance disponibilité
      imagePath: 'assets/images/car${index + 1}.jpg', // Chemin dynamique pour les images
    ),
  );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Réserver une voiture"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: voitures.length,
          itemBuilder: (context, index) {
            final voiture = voitures[index];
            final evaluation = EvaluationManager.evaluations[index] ?? 0;

            return Card(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    ListTile(
                      leading: Image.asset(
                        voiture.imagePath,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                      title: Text(voiture.nom),
                      subtitle: Text(
                        "Prix : \$${voiture.prix} / jour\n${voiture.estDisponible ? 'Disponible' : 'Indisponible'}",
                      ),
                      trailing: ElevatedButton(
                        onPressed: voiture.estDisponible
                            ? () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ReservationFormPage(voiture: voiture),
                                  ),
                                );
                              }
                            : null,
                        child: Text("Réserver"),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(5, (starIndex) {
                        return IconButton(
                          icon: Icon(
                            starIndex < evaluation ? Icons.star : Icons.star_border,
                            color: Colors.amber,
                          ),
                          onPressed: () {
                            setState(() {
                              EvaluationManager.evaluations[index] = starIndex + 1;
                            });
                          },
                        );
                      }),
                    ),
                    Text(
                      "Évaluation : $evaluation étoiles",
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

