import 'package:flutter/material.dart';

class HowItWorksPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Comment ça marche'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _buildFeatureSection(
                context,
                'Authentification',
                'L\'authentification sécurisée est le premier pas pour accéder à toutes les fonctionnalités de notre application. Que vous soyez utilisateur ou loueur de véhicules, vous pourrez créer un compte en quelques minutes en utilisant votre email ou votre numéro de téléphone. Pour garantir la sécurité, un système de mot de passe robuste est en place. Une fois authentifié, vous pourrez accéder à votre tableau de bord personnalisé et profiter pleinement de notre service.',
                'assets/images/authentication.png',
              ),
              _buildFeatureSection(
                context,
                'Réservation',
                'Réserver un véhicule n\'a jamais été aussi facile ! Avec notre fonction de recherche, vous pouvez rapidement trouver le véhicule qui correspond à vos besoins, en fonction de votre localisation, des dates souhaitées et de votre budget. Une fois le véhicule sélectionné, il vous suffit de le réserver en quelques clics. Vous recevrez une confirmation instantanée de votre réservation avec tous les détails nécessaires pour profiter de votre location en toute tranquillité.',
                'assets/images/reservation.png',
              ),
              _buildFeatureSection(
                context,
                'Paiement sécurisé',
                'Le paiement sécurisé est une priorité pour nous. Nous utilisons des technologies avancées de chiffrement pour protéger vos informations bancaires. Lors de la réservation, vous pourrez choisir votre mode de paiement préféré parmi plusieurs options (carte bancaire, mobile money, etc.). Une fois le paiement effectué, vous recevrez une confirmation instantanée et un reçu détaillé, garantissant ainsi une transaction en toute sécurité.',
                'assets/images/payement.jpg.png',
              ),
            
              
              
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureSection(BuildContext context, String title, String description, String imagePath) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8.0),
          Image.asset(imagePath, height: 150.0, fit: BoxFit.cover),
          SizedBox(height: 8.0),
          Text(description),
        ],
      ),
    );
  }
}
