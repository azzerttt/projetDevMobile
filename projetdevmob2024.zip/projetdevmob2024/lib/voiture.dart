class Voiture {
  final String nom;
  final double prix;
  final bool estDisponible;
  final String imagePath;

  Voiture({
    required this.nom,
    required this.prix,
    this.estDisponible = true,
    required this.imagePath,
  });
}
List<Voiture> voitures = [];