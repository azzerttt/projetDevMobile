import 'package:flutter/material.dart';
import 'voiture.dart';
import 'payment_dialog.dart';  // Importez le PayementDialog

class ReservationFormPage extends StatelessWidget {
  final Voiture voiture;

  ReservationFormPage({required this.voiture});

  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();

    String? nom, prenom, numTel, dateDebut, dateFin, carteIdentitePath;

    return Scaffold(
      appBar: AppBar(
        title: Text("Formulaire de réservation"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Text(
                "Réservation pour : ${voiture.nom}",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              TextFormField(
                decoration: InputDecoration(labelText: "Nom"),
                onSaved: (value) => nom = value,
                validator: (value) => value == null || value.isEmpty ? "Entrez votre nom" : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Prénom"),
                onSaved: (value) => prenom = value,
                validator: (value) => value == null || value.isEmpty ? "Entrez votre prénom" : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Numéro de téléphone"),
                keyboardType: TextInputType.phone,
                onSaved: (value) => numTel = value,
                validator: (value) => value == null || value.isEmpty ? "Entrez votre numéro" : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Date de début"),
                onSaved: (value) => dateDebut = value,
                validator: (value) => value == null || value.isEmpty ? "Entrez la date de début" : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Date de fin"),
                onSaved: (value) => dateFin = value,
                validator: (value) => value == null || value.isEmpty ? "Entrez la date de fin" : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  // Action pour sélectionner un fichier PDF
                  // Utilisez un package comme file_picker ici
                },
                child: Text("Joindre la photocopie de la carte d'identité (PDF)"),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    // Rediriger vers le PayementDialog
                    showDialog(
                      context: context,
                      builder: (context) => PaymentDialog(),
                    );
                  }
                },
                child: Text("Valider la réservation"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


