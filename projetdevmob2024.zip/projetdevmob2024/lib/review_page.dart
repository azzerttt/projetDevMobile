import 'package:flutter/material.dart';
import 'evaluation_manager.dart';
import 'voiture.dart';

class ReviewPage extends StatelessWidget {
  final List<Voiture> voitures = List.generate(
    15,
    (index) => Voiture(
      nom: "Voiture ${index + 1}",
      prix: 50.0 + (index * 5),
      estDisponible: index % 2 == 0, // Alternance disponibilité
      imagePath: 'assets/images/car1.jpg', // Remplacez par vos images
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Avis"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Évaluations des véhicules",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: EvaluationManager.evaluations.length,
                itemBuilder: (context, index) {
                  final voiture = voitures[index];
                  final evaluation = EvaluationManager.evaluations[index] ?? 0;

                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 10),
                    child: ListTile(
                      leading: Icon(Icons.star, color: Colors.orange, size: 40),
                      title: Text(voiture.nom, style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text("Note: $evaluation étoiles"),
                      trailing: Icon(Icons.arrow_forward),
                      onTap: () {
                        // Action pour afficher les détails (si nécessaire)
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
