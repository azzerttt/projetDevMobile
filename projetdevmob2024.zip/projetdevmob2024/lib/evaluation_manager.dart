// TODO Implement this library.
import 'voiture.dart';

class EvaluationManager {
  static final Map<int, int> evaluations = {};
}
