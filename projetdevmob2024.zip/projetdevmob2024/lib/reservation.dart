import 'voiture.dart';

class Reservation {
  final String nom;
  final String prenom;
  final String numTel;
  final String dateDebut;
  final String dateFin;
  final Voiture voiture;

  Reservation({
    required this.nom,
    required this.prenom,
    required this.numTel,
    required this.dateDebut,
    required this.dateFin,
    required this.voiture,
  });
}

List<Reservation> reservations = [];
